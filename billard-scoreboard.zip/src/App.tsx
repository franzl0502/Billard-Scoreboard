/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  Trophy, 
  User, 
  RotateCcw, 
  History, 
  Settings, 
  Timer, 
  Plus, 
  Minus, 
  Undo2,
  Play,
  Pause,
  X,
  Sun,
  Moon,
  Smartphone,
  Keyboard,
  Volume2,
  VolumeX
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type GameType = '8-Ball' | '9-Ball' | '10-Ball' | '14/1 Endlos';

interface Player {
  id: number;
  name: string;
  score: number;
  shots: number;
  shotHistory: number[];
  halftimeScore?: number;
}

interface MatchState {
  players: Player[];
  activePlayerIndex: number;
  totalShots: number;
}

export default function App() {
  const [gameType, setGameType] = useState<string>('Billard Kegeln');
  const [totalShotsLimit, setTotalShotsLimit] = useState<number | null>(null);
  const [controlMode, setControlMode] = useState<'smartphone' | 'keyboard'>('keyboard');
  const [selectedStartOption, setSelectedStartOption] = useState<number>(0); // 0 for 50, 1 for 100
  const [player, setPlayer] = useState<Player>(
    { id: 1, name: 'Spieler 1', score: 0, shots: 0, shotHistory: [] }
  );
  const [matchHistory, setMatchHistory] = useState<Player[]>([]);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [showHalftimePopup, setShowHalftimePopup] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isSilent, setIsSilent] = useState(false);
  const [clubName, setClubName] = useState('');
  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);
  const [selectedConfirmOption, setSelectedConfirmOption] = useState<number>(0); // 0 for Cancel, 1 for Confirm
  const [selectedHeaderOption, setSelectedHeaderOption] = useState<number>(-1); // -1: none, 0: theme, 1: stats, 2: restart, 3: end, 4: silent
  const [showStats, setShowStats] = useState(false);
  const isGameOver = totalShotsLimit !== null && player.shots >= totalShotsLimit;

  useEffect(() => {
    if (!isDarkMode) {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
  }, [isDarkMode]);

  // Load club name on mount
  useEffect(() => {
    const storedClub = localStorage.getItem('bk_scoreboard_club_name');
    if (storedClub) setClubName(storedClub);
  }, []);

  // Save club name whenever it changes
  useEffect(() => {
    localStorage.setItem('bk_scoreboard_club_name', clubName);
  }, [clubName]);

  // Prevent page reload during active game
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (totalShotsLimit !== null && player.shots > 0 && !isGameOver) {
        e.preventDefault();
        e.returnValue = ''; // Standard for modern browsers
        return '';
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [totalShotsLimit, player.shots, isGameOver]);

  // Speech synthesis helper
  const minusPressedRef = useRef(false);
  const [lastAddedPoints, setLastAddedPoints] = useState<number | null>(null);
  const [isFlashing, setIsFlashing] = useState(false);

  // Keyboard support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in the name input
      if (document.activeElement?.tagName === 'INPUT') return;

      const key = e.key;

      // Handle modals first
      if (confirmModal) {
        if (key === 'ArrowLeft') setSelectedConfirmOption(0);
        if (key === 'ArrowRight') setSelectedConfirmOption(1);
        if (key === 'Enter') {
          if (selectedConfirmOption === 1) {
            confirmModal.onConfirm();
          } else {
            setConfirmModal(null);
          }
          return;
        }
        if (key === 'Escape') {
          setConfirmModal(null);
          return;
        }
        return; // Block other keys when modal is open
      }

      if (showHalftimePopup) {
        if (key === 'Enter' || key === 'Escape') {
          setShowHalftimePopup(false);
          return;
        }
        return;
      }

      if (showStats) {
        if (key === 'Enter' || key === 'Escape') {
          setShowStats(false);
          return;
        }
        return;
      }

      // Start screen keyboard support
      if (totalShotsLimit === null) {
        if (key === 'ArrowLeft' || key === 'ArrowRight') {
          setSelectedStartOption(prev => prev === 0 ? 1 : 0);
        }
        if (key === 'Enter') {
          setTotalShotsLimit(selectedStartOption === 0 ? 50 : 100);
        }
        return;
      }

      // Disable keyboard support in main game if smartphone mode is selected
      if (controlMode === 'smartphone') return;
      
      // Main game keyboard support for header buttons
      if (totalShotsLimit !== null && !confirmModal && !showHalftimePopup && !showStats) {
        if (key === 'ArrowLeft') {
          setSelectedHeaderOption(prev => {
            const options = isGameOver ? [0, 4, 1, 2, 3] : [0, 4, 2, 3];
            const currentIndex = options.indexOf(prev);
            if (currentIndex === -1) return options[options.length - 1];
            const nextIndex = (currentIndex - 1 + options.length) % options.length;
            return options[nextIndex];
          });
          return;
        }
        if (key === 'ArrowRight') {
          setSelectedHeaderOption(prev => {
            const options = isGameOver ? [0, 4, 1, 2, 3] : [0, 4, 2, 3];
            const currentIndex = options.indexOf(prev);
            if (currentIndex === -1) return options[0];
            const nextIndex = (currentIndex + 1) % options.length;
            return options[nextIndex];
          });
          return;
        }
        if (key === 'Enter' && selectedHeaderOption !== -1) {
          if (selectedHeaderOption === 0) setIsDarkMode(prev => !prev);
          if (selectedHeaderOption === 4) setIsSilent(prev => !prev);
          if (selectedHeaderOption === 1 && isGameOver) setShowStats(true);
          if (selectedHeaderOption === 2) restartGame();
          if (selectedHeaderOption === 3) endGame();
          return;
        }
      }

      // Handle minus prefix
      if (key === '-' || key === 'Subtract') {
        minusPressedRef.current = true;
        return;
      }

      // Numbers 0-7
      if (key >= '0' && key <= '7') {
        const points = parseInt(key);
        if (minusPressedRef.current && points > 0) {
          updateScore(-points);
        } else {
          updateScore(points);
        }
        minusPressedRef.current = false;
        return;
      }

      // Reset minus prefix for any other key
      minusPressedRef.current = false;

      // Undo
      if (key === 'Backspace' || key === 'Delete' || key === '/') {
        undoLastAction();
      }

      // Theme toggle shortcut
      if (key === '*') {
        setIsDarkMode(prev => !prev);
      }

      // Restart
      if (key.toLowerCase() === 'r') {
        restartGame();
      }

      // End game
      if (key.toLowerCase() === 'q' || key === 'Escape') {
        endGame();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [totalShotsLimit, player.shots, startTime, matchHistory, confirmModal, showHalftimePopup, showStats, selectedStartOption, selectedConfirmOption, controlMode, selectedHeaderOption, isGameOver]);

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'de-DE';
      window.speechSynthesis.speak(utterance);
    }
  };

  const playConfirmSound = useCallback(() => {
    if (isSilent) return;
    try {
      const AudioCtxClass = (window.AudioContext || (window as any).webkitAudioContext);
      if (!AudioCtxClass) return;
      
      const audioCtx = new AudioCtxClass();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      
      gainNode.gain.setValueAtTime(0.05, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.1);
    } catch (e) {
      console.warn('Audio context failed', e);
    }
  }, [isSilent]);

  // Timer logic for match duration
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (startTime && totalShotsLimit && !isGameOver) {
      interval = setInterval(() => {
        setElapsedSeconds(Math.floor((Date.now() - startTime) / 1000));
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [startTime, totalShotsLimit, isGameOver]);

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const saveStateToHistory = () => {
    setMatchHistory(prev => [JSON.parse(JSON.stringify(player)), ...prev].slice(0, 100));
  };

  const undoLastAction = () => {
    if (matchHistory.length === 0) return;
    const previousState = matchHistory[0];
    setPlayer(previousState);
    setMatchHistory(prev => prev.slice(1));
    
    if (previousState.shots === 0) {
      setStartTime(null);
      setElapsedSeconds(0);
    }
  };

  const updateScore = (points: number) => {
    if (!totalShotsLimit || player.shots >= totalShotsLimit) return;

    if (player.shots === 0 && !startTime) {
      setStartTime(Date.now());
    }

    saveStateToHistory();

    const newShots = player.shots + 1;
    const newScore = player.score + points;
    
    let halftimeScore = player.halftimeScore;
    const halftimeTrigger = Math.floor(totalShotsLimit / 2);

    if (newShots === halftimeTrigger) {
      halftimeScore = newScore;
      setShowHalftimePopup(true);
      setTimeout(() => setShowHalftimePopup(false), 10000);
      speak(`Halbzeit. Ihr Punktestand beträgt ${newScore} Punkte.`);
    }

    if (newShots === totalShotsLimit - 10) {
      speak("Noch 10 Stöße verbleiben.");
    }

    if (newShots === totalShotsLimit) {
      speak(`Spiel beendet. Ihr Endergebnis beträgt ${newScore} Punkte.`);
    }

    setPlayer(prev => ({
      ...prev,
      score: newScore,
      shots: newShots,
      shotHistory: [...prev.shotHistory, points],
      halftimeScore
    }));

    // Handle last added points animation
    setLastAddedPoints(points);
    setIsFlashing(true);
    playConfirmSound();
    const timer = setTimeout(() => setIsFlashing(false), 1500); // 3 flashes of 0.5s total
    return () => clearTimeout(timer);
  };

  const restartGame = () => {
    setSelectedConfirmOption(0);
    setConfirmModal({
      title: 'Spiel neu starten',
      message: 'Möchten Sie das Spiel wirklich neu starten? Alle aktuellen Punkte gehen verloren.',
      onConfirm: () => {
        setPlayer({ 
          id: 1,
          name: player.name,
          score: 0, 
          shots: 0,
          shotHistory: []
        });
        setMatchHistory([]);
        setStartTime(null);
        setElapsedSeconds(0);
        setShowHalftimePopup(false);
        setConfirmModal(null);
      }
    });
  };

  const endGame = () => {
    setSelectedConfirmOption(0);
    setConfirmModal({
      title: 'Spiel beenden',
      message: 'Möchten Sie das Spiel wirklich beenden und zum Hauptmenü zurückkehren?',
      onConfirm: () => {
        setPlayer({ 
          id: 1,
          name: player.name,
          score: 0, 
          shots: 0,
          shotHistory: []
        });
        setMatchHistory([]);
        setStartTime(null);
        setElapsedSeconds(0);
        setShowHalftimePopup(false);
        setTotalShotsLimit(null);
        setConfirmModal(null);
      }
    });
  };

  const updatePlayerName = (name: string) => {
    setPlayer(prev => ({ ...prev, name }));
  };

  const getScoreColorClass = (score: number) => {
    if (!isDarkMode) {
      if (score === 0) return 'text-black';
      if (score > 0) return 'text-[#2e7d32]'; // Success green
      return 'text-[#d32f2f]'; // Danger red
    }
    // Dark mode defaults
    if (score < 0) return 'text-hardware-danger';
    return 'text-hardware-accent';
  };

  const scoringOptions = [-7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7];

  const negativePointsSum = player.shotHistory.filter(p => p < 0).reduce((a, b) => a + b, 0);
  const negativeCount = player.shotHistory.filter(p => p < 0).length;
  const positiveAnalysis = [1, 2, 3, 4, 5, 6, 7].map(val => ({
    val,
    count: player.shotHistory.filter(p => p === val).length
  }));
  const zeroCount = player.shotHistory.filter(p => p === 0).length;

  const cumulativeScores: { score: number; isNegative: boolean }[] = [];
  let currentSum = 0;
  player.shotHistory.forEach((pts) => {
    currentSum += pts;
    cumulativeScores.push({ score: currentSum, isNegative: pts < 0 });
  });

  if (totalShotsLimit === null) {
    return (
      <div className="min-h-screen bg-hardware-bg flex items-center justify-center p-2 sm:p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-hardware-card border border-white/10 rounded-3xl p-5 sm:p-8 md:p-10 max-w-xl w-full hardware-glow text-center relative overflow-hidden"
        >
          <div className="flex flex-col justify-between items-center gap-4 mb-6 sm:mb-8">
            <div className="flex gap-2">
              <button 
                onClick={() => setControlMode(prev => prev === 'keyboard' ? 'smartphone' : 'keyboard')}
                className={`p-3 rounded-full transition-all border-2 flex items-center justify-center ${
                  controlMode === 'smartphone'
                    ? 'bg-hardware-accent border-hardware-accent text-hardware-bg hardware-glow'
                    : (!isDarkMode ? 'bg-white/5 border-gray-300 text-black' : 'bg-white/5 border-white/10 text-white')
                }`}
                title={controlMode === 'smartphone' ? 'Smartphone-Modus aktiv' : 'Tastatur-Modus aktiv'}
              >
                <Smartphone className="w-6 h-6" />
              </button>
              <button 
                onClick={() => setIsSilent(!isSilent)}
                className={`p-3 bg-white/5 hover:bg-white/10 rounded-full transition-colors border-2 ${
                  isSilent 
                    ? 'text-hardware-danger border-hardware-danger/20' 
                    : (!isDarkMode ? 'text-black border-gray-300' : 'text-white border-white/10')
                }`}
                title={isSilent ? 'Lautlosmodus aktiv' : 'Ton aktiv'}
              >
                {isSilent ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
              </button>
              <button 
                onClick={() => setIsDarkMode(!isDarkMode)}
                className={`p-3 bg-white/5 hover:bg-white/10 rounded-full transition-colors border-2 ${!isDarkMode ? 'text-black border-gray-300' : 'text-white border-white/10'}`}
                title={isDarkMode ? 'Hellmodus' : 'Dunkelmodus'}
              >
                {isDarkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
              </button>
            </div>
            <h1 className="text-2xl sm:text-4xl font-bold text-[#2e7d32] uppercase tracking-tight">Billard Scoreboard</h1>
          </div>

          <div className="space-y-4 sm:space-y-6">
            <div className="space-y-3 sm:space-y-4">
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-hardware-muted group-focus-within:text-hardware-accent transition-colors" />
                </div>
                <input
                  type="text"
                  value={player.name}
                  onChange={(e) => updatePlayerName(e.target.value)}
                  placeholder="Spieler Name"
                  className={`w-full bg-white/5 border-2 pl-12 pr-4 py-4 rounded-2xl outline-none transition-all placeholder:text-hardware-muted/50 ${
                    !isDarkMode ? 'border-gray-300 focus:border-[#2e7d32] text-black' : 'border-white/10 focus:border-hardware-accent text-white'
                  }`}
                />
              </div>
              
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Trophy className="h-5 w-5 text-hardware-muted group-focus-within:text-hardware-accent transition-colors" />
                </div>
                <input
                  type="text"
                  value={clubName}
                  onChange={(e) => setClubName(e.target.value)}
                  placeholder="Verein"
                  className={`w-full bg-white/5 border-2 pl-12 pr-4 py-4 rounded-2xl outline-none transition-all placeholder:text-hardware-muted/50 ${
                    !isDarkMode ? 'border-gray-200 focus:border-[#2e7d32] text-black' : 'border-white/10 focus:border-hardware-accent text-white'
                  }`}
                />
              </div>
            </div>

            <div>
              <p className={`uppercase text-xs font-bold tracking-widest mb-4 ${!isDarkMode ? 'text-black/60' : 'text-white/60'}`}>Anzahl der Stöße wählen</p>
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={() => setSelectedStartOption(0)}
                  onMouseEnter={() => setSelectedStartOption(0)}
                  className={`group relative bg-white/5 border-2 p-4 sm:p-6 rounded-2xl transition-all flex flex-col items-center justify-center ${
                    selectedStartOption === 0 
                      ? 'border-hardware-accent bg-hardware-accent/10' 
                      : (!isDarkMode ? 'border-gray-300' : 'border-white/10')
                  }`}
                >
                  <div className={`text-4xl sm:text-5xl font-calibri font-bold mb-1 ${
                    selectedStartOption === 0 ? 'text-hardware-accent' : (!isDarkMode ? 'text-black' : 'text-white')
                  }`}>50</div>
                  <div className={`text-[10px] md:text-xs uppercase font-bold ${
                    selectedStartOption === 0 ? 'text-hardware-accent/70' : (!isDarkMode ? 'text-black/60' : 'text-hardware-muted')
                  }`}>Stöße</div>
                </button>
                <button 
                  onClick={() => setSelectedStartOption(1)}
                  onMouseEnter={() => setSelectedStartOption(1)}
                  className={`group relative bg-white/5 border-2 p-4 sm:p-6 rounded-2xl transition-all flex flex-col items-center justify-center ${
                    selectedStartOption === 1 
                      ? 'border-hardware-accent bg-hardware-accent/10' 
                      : (!isDarkMode ? 'border-gray-300' : 'border-white/10')
                  }`}
                >
                  <div className={`text-4xl sm:text-5xl font-calibri font-bold mb-1 ${
                    selectedStartOption === 1 ? 'text-hardware-accent' : (!isDarkMode ? 'text-black' : 'text-white')
                  }`}>100</div>
                  <div className={`text-[10px] md:text-xs uppercase font-bold ${
                    selectedStartOption === 1 ? 'text-hardware-accent/70' : (!isDarkMode ? 'text-black/60' : 'text-hardware-muted')
                  }`}>Stöße</div>
                </button>
              </div>
            </div>

            <button 
              onClick={() => {
                setTotalShotsLimit(selectedStartOption === 0 ? 50 : 100);
              }}
              className="w-full py-4 bg-hardware-accent text-hardware-bg font-bold rounded-2xl uppercase tracking-widest hover:bg-white transition-all hardware-glow text-lg"
            >
              Spiel starten
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  const renderStatsModal = (data: Player) => {
    const statsPlayer = data;
    const displayDate = new Date();
    
    const statsNegativeSum = statsPlayer.shotHistory.filter(p => p < 0).reduce((a, b) => a + b, 0);
    const statsNegativeCount = statsPlayer.shotHistory.filter(p => p < 0).length;
    const statsZeroCount = statsPlayer.shotHistory.filter(p => p === 0).length;
    const statsPositiveAnalysis = [1, 2, 3, 4, 5, 6, 7].map(val => ({
      val,
      count: statsPlayer.shotHistory.filter(p => p === val).length
    }));

    const statsDuration = elapsedSeconds;
    const statsLimit = totalShotsLimit;
    const statsClub = clubName;

    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-hardware-bg/95 backdrop-blur-md"
      >
        <motion.div 
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="bg-hardware-card border border-white/10 p-6 md:p-12 rounded-3xl hardware-glow max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        >
          <div className="flex justify-between items-start mb-10">
            <div>
              <h2 className={`text-4xl md:text-6xl font-bold uppercase tracking-tighter ${!isDarkMode ? 'text-[#2e7d32]' : 'text-hardware-accent'}`}>Endergebnis</h2>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2">
                <p className="text-hardware-muted uppercase text-sm tracking-widest">{statsPlayer.name} {statsClub && `• ${statsClub}`} • {statsLimit} Stöße</p>
                <p className="text-hardware-accent/60 uppercase text-[10px] tracking-widest font-mono">
                  {displayDate.toLocaleDateString()} {displayDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
            <button 
              onClick={() => setShowStats(false)}
              className="p-2 hover:bg-white/5 rounded-full transition-colors"
            >
              <X className="w-8 h-8 text-hardware-muted" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
            <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
              <div className="text-xs text-hardware-muted uppercase mb-2">Halbzeit</div>
              <div className={`text-4xl font-bold font-calibri ${getScoreColorClass(statsPlayer.halftimeScore || 0)}`}>
                {statsPlayer.halftimeScore ?? '---'}
              </div>
            </div>
            <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
              <div className="text-xs text-hardware-muted uppercase mb-2">Punktzahl</div>
              <div className={`text-4xl font-bold font-calibri ${getScoreColorClass(statsPlayer.score)}`}>
                {statsPlayer.score}
              </div>
            </div>
            <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
              <div className="text-xs text-hardware-muted uppercase mb-2">Dauer</div>
              <div className={`text-4xl font-bold font-calibri ${!isDarkMode ? 'text-black' : 'text-white'}`}>
                {formatTime(statsDuration)}
              </div>
            </div>
            <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
              <div className="text-xs text-hardware-muted uppercase mb-2">Minuspunkte</div>
              <div className="text-4xl font-bold font-calibri text-hardware-danger">
                {statsNegativeSum}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-lg font-bold uppercase tracking-widest text-hardware-muted border-b border-white/5 pb-2">Spielanalyse</h3>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-9 gap-3">
              <div className="bg-white/5 p-4 rounded-xl border border-white/5 text-center">
                <div className="text-xs text-hardware-muted mb-2">Minus</div>
                <div className="text-3xl font-bold font-calibri text-hardware-danger">{statsNegativeCount}</div>
              </div>
              <div className="bg-white/5 p-4 rounded-xl border border-white/5 text-center">
                <div className="text-xs text-hardware-muted mb-2">Null</div>
                <div className={`text-3xl font-bold font-calibri ${!isDarkMode ? 'text-black' : 'text-white'}`}>{statsZeroCount}</div>
              </div>
              {statsPositiveAnalysis.map(({ val, count }) => (
                <div key={val} className="bg-white/5 p-4 rounded-xl border border-white/5 text-center">
                  <div className="text-xs text-hardware-muted mb-2">+{val}</div>
                  <div className="text-3xl font-bold font-calibri text-hardware-accent">{count}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-center mt-10">
            <button 
              onClick={() => setShowStats(false)}
              className="w-full sm:w-64 py-4 font-bold rounded-2xl uppercase tracking-widest transition-all bg-hardware-accent text-hardware-bg ring-4 ring-white/20 hover:bg-white"
            >
              Schließen
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  };

  return (
    <div className="h-screen bg-hardware-bg flex flex-col p-2 md:p-4 w-full mx-auto relative overflow-hidden">
      {/* Confirmation Modal */}
      <AnimatePresence>
        {confirmModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-hardware-bg/90 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-hardware-card border border-white/10 p-8 rounded-3xl hardware-glow text-center max-w-md w-full"
            >
              <h2 className={`text-2xl font-bold uppercase mb-4 ${!isDarkMode ? 'text-black' : 'text-white'}`}>{confirmModal.title}</h2>
              <p className="text-hardware-muted mb-8">{confirmModal.message}</p>
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={() => setConfirmModal(null)}
                  onMouseEnter={() => setSelectedConfirmOption(0)}
                  className={`px-2 sm:px-6 py-3 font-bold rounded-xl uppercase tracking-widest transition-all border-2 text-[10px] sm:text-sm md:text-base ${
                    selectedConfirmOption === 0 
                      ? 'border-hardware-accent bg-hardware-accent/10 text-hardware-accent' 
                      : (!isDarkMode ? 'border-gray-300 text-black bg-white/5' : 'border-white/10 text-white bg-white/5')
                  }`}
                >
                  Abbrechen
                </button>
                <button 
                  onClick={confirmModal.onConfirm}
                  onMouseEnter={() => setSelectedConfirmOption(1)}
                  className={`px-2 sm:px-6 py-3 font-bold rounded-xl uppercase tracking-widest transition-all border-2 text-[10px] sm:text-sm md:text-base ${
                    selectedConfirmOption === 1 
                      ? 'border-hardware-danger bg-hardware-danger/10 text-hardware-danger' 
                      : (!isDarkMode ? 'border-gray-300 text-black bg-white/5' : 'border-white/10 text-white bg-white/5')
                  }`}
                >
                  Ja
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Halftime Popup */}
      <AnimatePresence>
        {showHalftimePopup && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-hardware-bg/80 backdrop-blur-md"
          >
            <div className={`bg-hardware-card border-4 p-6 md:p-12 rounded-3xl hardware-glow text-center max-w-2xl w-full ${!isDarkMode ? 'border-[#2e7d32]' : 'border-hardware-accent'}`}>
              <h2 className={`text-4xl md:text-8xl font-bold uppercase mb-4 md:mb-8 tracking-tighter ${!isDarkMode ? 'text-[#2e7d32]' : 'text-hardware-accent'}`}>Halbzeit</h2>
              <div className={`text-lg md:text-2xl uppercase font-calibri mb-2 md:mb-4 ${!isDarkMode ? 'text-black/60' : 'text-hardware-muted'}`}>Aktueller Punktestand</div>
              <div className={`text-7xl md:text-9xl font-calibri font-bold lcd-display ${getScoreColorClass(player.score)}`}>
                {player.score}
              </div>
              <button 
                onClick={() => setShowHalftimePopup(false)}
                className="mt-8 md:mt-12 px-6 py-3 md:px-8 md:py-4 bg-hardware-accent text-hardware-bg font-bold rounded-xl uppercase tracking-widest hover:bg-white transition-colors"
              >
                Schließen
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <header className="flex flex-col sm:flex-row justify-between items-center gap-2 mb-2 md:mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-hardware-accent rounded-full flex items-center justify-center hardware-glow">
            <Trophy className="text-hardware-bg w-6 h-6" />
          </div>
          <div>
            <h1 className={`text-xl font-bold tracking-tight uppercase ${!isDarkMode ? 'text-[#2e7d32]' : 'text-white'}`}>Billard Scoreboard</h1>
          </div>
        </div>
        
        <div className="flex gap-2 sm:gap-3 w-full sm:w-auto overflow-x-auto pb-2 sm:pb-0">
          <button 
            onClick={() => setIsDarkMode(!isDarkMode)}
            onMouseEnter={() => setSelectedHeaderOption(0)}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-bold uppercase transition-all border whitespace-nowrap ${
              selectedHeaderOption === 0 
                ? 'border-hardware-accent bg-hardware-accent/10 ring-2 ring-hardware-accent ring-inset' 
                : (!isDarkMode ? 'text-black border-gray-300' : 'text-white border-white/5')
            }`}
            title={isDarkMode ? 'Hellmodus' : 'Dunkelmodus'}
          >
            {isDarkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isDarkMode ? 'Hell' : 'Dunkel'}</span>
          </button>

          <button 
            onClick={() => setIsSilent(!isSilent)}
            onMouseEnter={() => setSelectedHeaderOption(4)}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-bold uppercase transition-all border whitespace-nowrap ${
              selectedHeaderOption === 4 
                ? (isSilent ? 'border-hardware-danger bg-hardware-danger/10 text-hardware-danger' : 'border-hardware-accent bg-hardware-accent/10 text-hardware-accent')
                : (isSilent ? 'text-hardware-danger border-hardware-danger/20' : (!isDarkMode ? 'text-black border-gray-300' : 'text-white border-white/5'))
            }`}
            title={isSilent ? 'Stumm schalten' : 'Ton einschalten'}
          >
            {isSilent ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isSilent ? 'Lautlos' : 'Ton'}</span>
          </button>
          
          {isGameOver && (
            <button 
              onClick={() => setShowStats(true)}
              onMouseEnter={() => setSelectedHeaderOption(1)}
              className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-[10px] font-bold uppercase transition-all whitespace-nowrap ${
                selectedHeaderOption === 1
                  ? 'bg-hardware-accent text-hardware-bg ring-4 ring-white/20'
                  : 'bg-hardware-accent text-hardware-bg hardware-glow'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Auswertung</span>
            </button>
          )}

          <button 
            onClick={restartGame}
            onMouseEnter={() => setSelectedHeaderOption(2)}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-bold uppercase transition-all border whitespace-nowrap ${
              selectedHeaderOption === 2
                ? 'border-hardware-accent bg-hardware-accent/10 ring-2 ring-hardware-accent ring-inset'
                : (!isDarkMode ? 'text-black border-gray-300' : 'text-white border-white/5')
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Neu starten</span>
          </button>
          <button 
            onClick={endGame}
            onMouseEnter={() => setSelectedHeaderOption(3)}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-[10px] font-bold uppercase transition-all border whitespace-nowrap ${
              selectedHeaderOption === 3
                ? 'bg-hardware-danger text-white ring-4 ring-hardware-danger/20'
                : 'bg-hardware-danger/10 hover:bg-hardware-danger/20 text-hardware-danger border-hardware-danger/20'
            }`}
          >
            <X className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Beenden</span>
          </button>
        </div>
      </header>

      {/* Statistics Modal */}
      <AnimatePresence>
        {showStats && renderStatsModal(player)}
      </AnimatePresence>

      {/* Main Score Area */}
      <main className="mb-2 md:mb-4 shrink-0 px-1 sm:px-0">
        <motion.div 
          initial={false}
          animate={{ 
            borderColor: 'rgba(0, 255, 157, 0.3)'
          }}
          className="relative bg-hardware-card rounded-2xl border-2 p-2 sm:p-4 flex flex-col hardware-glow"
        >
          <div className="flex flex-col sm:flex-row justify-between items-center gap-2 mb-2 sm:mb-4 border-b border-white/5 pb-2">
            <div className="flex items-center gap-2 sm:gap-3 w-full sm:w-auto">
              <div className="w-8 h-8 rounded-xl flex items-center justify-center bg-hardware-accent/20 text-hardware-accent shrink-0">
                <User className="w-5 h-5" />
              </div>
              <input 
                type="text" 
                value={player.name}
                onChange={(e) => updatePlayerName(e.target.value)}
                className={`bg-transparent border-none focus:ring-0 text-base sm:text-xl font-bold uppercase w-full sm:w-48 ${!isDarkMode ? 'text-black' : 'text-white'}`}
              />
            </div>
            
            <div className="flex flex-wrap justify-between sm:justify-end gap-x-4 gap-y-1 w-full sm:w-auto">
              <div className="text-center">
                <div className="text-[8px] md:text-[9px] text-hardware-muted uppercase font-mono mb-0.5 tracking-widest">Spielart</div>
                <div className="text-lg md:text-xl font-bold text-hardware-accent uppercase font-calibri">
                  {totalShotsLimit}
                </div>
              </div>

              <div className="text-center relative">
                <div className="text-[8px] md:text-[9px] text-hardware-muted uppercase font-mono mb-0.5 tracking-widest">Dauer</div>
                <div className={`text-lg md:text-xl font-bold font-calibri ${!isDarkMode ? 'text-black' : 'text-white'}`}>
                  {formatTime(elapsedSeconds)}
                </div>
                {startTime && (
                  <div className="absolute -bottom-1 left-0 h-0.5 bg-hardware-accent w-full animate-pulse" />
                )}
              </div>

              {player.halftimeScore !== undefined && (
                <div className="text-center">
                  <div className="text-[8px] md:text-[9px] text-hardware-muted uppercase font-mono mb-0.5 tracking-widest">Halbzeit</div>
                  <div className={`text-lg md:text-xl font-calibri font-bold lcd-display ${getScoreColorClass(player.halftimeScore)}`}>
                    {player.halftimeScore}
                  </div>
                </div>
              )}

              <div className="text-center">
                <div className="text-[8px] md:text-[9px] text-hardware-muted uppercase font-mono mb-0.5 tracking-widest">Minuspunkte</div>
                <div className={`text-lg md:text-xl font-calibri font-bold lcd-display ${getScoreColorClass(negativePointsSum)}`}>
                  {negativePointsSum}
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-1 sm:gap-4 items-center py-1 sm:py-2">
            <div className={`flex flex-col items-center justify-center order-1 border rounded-xl p-1 sm:p-3 ${!isDarkMode ? 'border-gray-200' : 'border-white/5'}`}>
              <div className="text-[7px] sm:text-[10px] text-hardware-muted uppercase font-mono tracking-widest">Stöße</div>
              <div className={`text-4xl sm:text-8xl md:text-9xl font-calibri font-bold lcd-display leading-none ${!isDarkMode ? 'text-black' : 'text-white'}`}>
                {player.shots}
              </div>
            </div>

            <div className={`flex flex-col items-center justify-center order-2 border rounded-xl p-1 sm:p-3 ${!isDarkMode ? 'border-gray-200' : 'border-white/5'}`}>
              <div className="text-[7px] sm:text-[10px] text-hardware-muted uppercase font-mono tracking-widest">Punkte</div>
              <div className={`text-4xl sm:text-8xl md:text-9xl font-calibri font-bold lcd-display leading-none ${getScoreColorClass(player.score)}`}>
                {player.score}
              </div>
            </div>

            <div className={`flex flex-col items-center justify-center order-3 border rounded-xl p-1 sm:p-3 ${!isDarkMode ? 'border-gray-200' : 'border-white/5'}`}>
              <div className="text-[7px] sm:text-[10px] text-hardware-muted uppercase font-mono tracking-widest">Prognose</div>
              <div className={`text-4xl sm:text-8xl md:text-9xl font-calibri font-bold text-hardware-muted lcd-display leading-none`}>
                {player.shots > 0 ? Math.round((player.score / player.shots) * totalShotsLimit) : '---'}
              </div>
            </div>
          </div>
        </motion.div>
      </main>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-2 md:gap-4 items-stretch flex-1 overflow-hidden min-h-0">
        {/* Scoring Grid & Controls */}
        {controlMode === 'smartphone' && (
          <div className={`bg-hardware-card rounded-2xl p-2 sm:p-3 h-full flex flex-col overflow-hidden border ${!isDarkMode ? 'border-gray-300' : 'border-white/5'} lg:col-span-6 md:col-span-12 shrink-0 md:shrink`}>
            <div className="flex justify-between items-center mb-1 sm:mb-2 shrink-0">
              <h3 className="text-[9px] text-hardware-muted uppercase font-mono tracking-widest">Punktewahl</h3>
              
              {lastAddedPoints !== null && (
                  <div className={`px-3 py-1 rounded-lg border text-sm md:text-lg lg:text-xl font-calibri font-bold uppercase tracking-widest transition-all duration-300 ${
                    isFlashing 
                      ? `animate-[pulse_0.5s_ease-in-out_infinite] ${
                          lastAddedPoints > 0 ? 'text-[#2e7d32] border-[#2e7d32] bg-[#2e7d32]/10' : 
                          lastAddedPoints < 0 ? 'text-[#d32f2f] border-[#d32f2f] bg-[#d32f2f]/10' : 
                          (!isDarkMode ? 'text-black border-black bg-black/10' : 'text-white border-white bg-white/10')
                        }` 
                      : (!isDarkMode ? 'text-black/20 border-gray-200 bg-black/5' : 'text-hardware-muted/40 border-white/5 bg-white/5')
                  }`}>
                    {lastAddedPoints > 0 ? `+${lastAddedPoints}` : lastAddedPoints}
                  </div>
              )}

              <button 
                onClick={undoLastAction}
                disabled={matchHistory.length === 0}
                className={`flex items-center gap-1 md:gap-2 px-2 py-0.5 md:px-3 md:py-1 bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed rounded-xl text-[7px] md:text-[8px] font-bold uppercase transition-colors border ${!isDarkMode ? 'text-black border-gray-300' : 'text-white border-white/5'}`}
              >
                <Undo2 className="w-2.5 h-2.5 md:w-3 md:h-3" />
                Korrektur
              </button>
            </div>

            <div className={`grid grid-cols-5 gap-1 overflow-hidden pr-1 flex-1 content-start ${controlMode === 'smartphone' ? 'grid-rows-[repeat(3,minmax(0,1fr))]' : ''}`}>
              {scoringOptions.map((points) => (
                <button
                  key={points}
                  onClick={() => updateScore(points)}
                  className={`flex items-center justify-center rounded-xl font-calibri font-bold text-lg md:text-xl lg:text-4xl transition-all touch-manipulation h-full
                    ${points > 0 ? (!isDarkMode ? 'bg-[#2e7d32]/10 text-[#2e7d32] hover:bg-[#2e7d32]/20' : 'bg-hardware-accent/10 text-hardware-accent hover:bg-hardware-accent/20') : 
                      points < 0 ? 'bg-hardware-danger/10 text-hardware-danger hover:bg-hardware-danger/20' : 
                      (!isDarkMode ? 'bg-black/5 text-black hover:bg-black/10' : 'bg-white/5 text-white hover:bg-white/10')}
                  `}
                >
                  {points > 0 ? `+${points}` : points}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Cumulative Score Grid */}
        <div className={`bg-hardware-card rounded-2xl p-2 sm:p-3 h-full flex flex-col overflow-hidden border ${!isDarkMode ? 'border-gray-300' : 'border-white/5'} 
          ${controlMode === 'keyboard' ? 'md:col-span-12' : 'lg:col-span-6 md:col-span-12'} flex-1 md:flex-none lg:flex-1`}>
          <div className="flex justify-between items-center mb-1 sm:mb-2 shrink-0">
            <h3 className="text-[9px] text-hardware-muted uppercase font-mono tracking-widest">Verlauf</h3>
            
            {controlMode === 'keyboard' && (
              <div className="flex items-center gap-4">
                {lastAddedPoints !== null && (
                  <div className={`px-4 py-1.5 rounded-xl border text-sm md:text-xl lg:text-2xl font-calibri font-bold uppercase tracking-widest transition-all duration-300 ${
                    isFlashing 
                      ? `animate-[pulse_0.5s_ease-in-out_infinite] ${
                          lastAddedPoints > 0 ? 'text-[#2e7d32] border-[#2e7d32] bg-[#2e7d32]/10' : 
                          lastAddedPoints < 0 ? 'text-[#d32f2f] border-[#d32f2f] bg-[#d32f2f]/10' : 
                          (!isDarkMode ? 'text-black border-black bg-black/10' : 'text-white border-white bg-white/10')
                        }` 
                      : (!isDarkMode ? 'text-black/20 border-gray-200 bg-black/5' : 'text-hardware-muted/40 border-white/5 bg-white/5')
                  }`}>
                    {lastAddedPoints > 0 ? `+${lastAddedPoints}` : lastAddedPoints}
                  </div>
                )}

                <button 
                  onClick={undoLastAction}
                  disabled={matchHistory.length === 0}
                  className={`flex items-center gap-1 md:gap-2 px-2 py-0.5 md:px-3 md:py-1 bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed rounded-xl text-[7px] md:text-[8px] font-bold uppercase transition-colors border ${!isDarkMode ? 'text-black border-gray-300' : 'text-white border-white/5'}`}
                >
                  <Undo2 className="w-2.5 h-2.5 md:w-3 md:h-3" />
                  Korrektur
                </button>
              </div>
            )}
          </div>
          
          <div className={`grid gap-0.5 md:gap-1 overflow-hidden pr-1 flex-1 content-start ${
            controlMode === 'keyboard' 
              ? (totalShotsLimit === 50 ? 'grid-rows-[repeat(5,minmax(0,1fr))] grid-cols-10' : 'grid-rows-[repeat(10,minmax(0,1fr))] grid-cols-10') 
              : (totalShotsLimit === 50 ? 'grid-rows-[repeat(5,minmax(0,1fr))] grid-cols-10' : 'grid-rows-[repeat(10,minmax(0,1fr))] grid-cols-10')
          }`}>
            {Array.from({ length: totalShotsLimit }).map((_, i) => {
              const data = cumulativeScores[i];
              const shotPoints = player.shotHistory[i];
              
              return (
                <div 
                  key={i} 
                  className={`flex items-center justify-center rounded border font-calibri transition-all h-full
                    ${!isDarkMode ? 'border-gray-300' : 'border-white/20'}
                    ${data ? 'bg-white/5' : 'bg-transparent opacity-20'}
                    ${controlMode === 'keyboard' ? 'p-0.5' : 'p-0.5'}
                  `}
                >
                  <span className={`font-bold leading-none ${
                    controlMode === 'keyboard' 
                      ? 'text-[16px] sm:text-[20px] md:text-[26px] lg:text-[32px] xl:text-[40px]' 
                      : 'text-[10px] sm:text-[12px] md:text-[14px] lg:text-[18px]'
                  } ${data?.isNegative ? 'text-hardware-danger' : 'text-hardware-text'}`}>
                    {data ? (shotPoints === 0 ? 'X' : data.score) : '-'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

